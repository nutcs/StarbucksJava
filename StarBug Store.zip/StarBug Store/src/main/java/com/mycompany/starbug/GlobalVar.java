/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.starbug;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import javax.swing.Icon;

/**
 *
 * @author uSeR
 */
public class GlobalVar {
    public static boolean LoginStatus = false;
    public static boolean ReceiptStatus = false;
    
    public static boolean Ordered = false;
    public static String Order;
    public static String OrderNo;
    public static String Table;
    public static String OrderTime;
    public static String Menu;
    public static String Size;
    public static String Milk;
    public static String CoffeeType;
    public static int CoffeePrice;
    public static int MilkPrice;
    public static Icon Icon;
    public static int SubTotal;
    
    public static String FName;
    public static String LName;
    
    public static List<UserData> UserList = new ArrayList<>();
    
    //Receipt
    public static LinkedList<AddOrder> orders = new LinkedList<AddOrder>();
    // status show next ,un do
    public static boolean statusNext;
}
