/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.starbug;

/**
 *
 * @author SFXW11
 */
public class AddOrder {
    private String Order;  
    private String OrderNo; 
    private String Table;  
    private String OrderTime; 
    private String Menu; 
    private String Size; 
    private String Milk; 
    private String CoffeeType; 
    private int CoffeePrice = 0; 
    private int MilkPrice = 0; 
    private String FName; 
    private String LName; 

    /**
     * @return the Order
     */
    public String getOrder() {
        return Order;
    }

    /**
     * @param Order the Order to set
     */
    public void setOrder(String Order) {
        this.Order = Order;
    }

    /**
     * @return the OrderNo
     */
    public String getOrderNo() {
        return OrderNo;
    }

    /**
     * @param OrderNo the OrderNo to set
     */
    public void setOrderNo(String OrderNo) {
        this.OrderNo = OrderNo;
    }

    /**
     * @return the Table
     */
    public String getTable() {
        return Table;
    }

    /**
     * @param Table the Table to set
     */
    public void setTable(String Table) {
        this.Table = Table;
    }

    /**
     * @return the OrderTime
     */
    public String getOrderTime() {
        return OrderTime;
    }

    /**
     * @param OrderTime the OrderTime to set
     */
    public void setOrderTime(String OrderTime) {
        this.OrderTime = OrderTime;
    }

    /**
     * @return the Menu
     */
    public String getMenu() {
        return Menu;
    }

    /**
     * @param Menu the Menu to set
     */
    public void setMenu(String Menu) {
        this.Menu = Menu;
    }

    /**
     * @return the Size
     */
    public String getSize() {
        return Size;
    }

    /**
     * @param Size the Size to set
     */
    public void setSize(String Size) {
        this.Size = Size;
    }

    /**
     * @return the Milk
     */
    public String getMilk() {
        return Milk;
    }

    /**
     * @param Milk the Milk to set
     */
    public void setMilk(String Milk) {
        this.Milk = Milk;
    }

    /**
     * @return the CoffeeType
     */
    public String getCoffeeType() {
        return CoffeeType;
    }

    /**
     * @param CoffeeType the CoffeeType to set
     */
    public void setCoffeeType(String CoffeeType) {
        this.CoffeeType = CoffeeType;
    }

    /**
     * @return the CoffeePrice
     */
    public int getCoffeePrice() {
        return CoffeePrice;
    }

    /**
     * @param CoffeePrice the CoffeePrice to set
     */
    public void setCoffeePrice(int CoffeePrice) {
        this.CoffeePrice = CoffeePrice;
    }

    /**
     * @return the MilkPrice
     */
    public int getMilkPrice() {
        return MilkPrice;
    }

    /**
     * @param MilkPrice the MilkPrice to set
     */
    public void setMilkPrice(int MilkPrice) {
        this.MilkPrice = MilkPrice;
    }

    /**
     * @return the FName
     */
    public String getFName() {
        return FName;
    }

    /**
     * @param FName the FName to set
     */
    public void setFName(String FName) {
        this.FName = FName;
    }

    /**
     * @return the LName
     */
    public String getLName() {
        return LName;
    }

    /**
     * @param LName the LName to set
     */
    public void setLName(String LName) {
        this.LName = LName;
    }
}
