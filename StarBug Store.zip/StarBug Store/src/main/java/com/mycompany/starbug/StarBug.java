/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.starbug;

/**
 *
 * @author uSeR
 */
public class StarBug {

    public static void main(String[] args) {
        Home home = new Home();
        home.setVisible(true);
    }
}
