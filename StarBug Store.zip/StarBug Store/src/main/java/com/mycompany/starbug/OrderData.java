/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.starbug;

/**
 *
 * @author uSeR
 */
public class OrderData {
    private String OrderNumber;
    private String FNameAndLName;
    private String Date;
    private String Coffee;
    private String CoffeePrice;
    private String Milk;
    private String MilkPrice;
    private String CoffeeType;
    private String SubTotal;
    private String Discount;
    private String Total;
    
}
